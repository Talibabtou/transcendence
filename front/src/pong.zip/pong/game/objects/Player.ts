import { Ball } from './Ball';
import { Paddle } from './Paddle';
import { GraphicalElement, GameContext, Direction, PlayerPosition, PlayerType, GameState } from '@pong/types';
import { COLORS, calculateGameSizes, KEYS, BALL_CONFIG } from '@pong/constants';

// Assuming VelocityValue is defined as: interface VelocityValue { dx: number; dy: number; }
// For the purpose of this edit, we'll assume it (or a similar type) is available.
// If not, it should be defined here or imported.
interface VelocityValue { dx: number; dy: number; }

/**
 * Represents a player in the game, managing paddle movement,
 * input handling, scoring, and AI behavior.
 */
export class Player implements GraphicalElement {

	public paddle: Paddle;
	public paddleWidth: number = 10;
	public paddleHeight: number = 100;
	private direction: Direction = Direction.NONE;
	private speed: number = 0;
	private color: string = COLORS.PADDLE;
	private score = 0;
	private upPressed = false;
	private downPressed = false;
	private _name: string = 'Player';
	private _type: PlayerType;
	private _position: PlayerPosition;
	private _upKey: string;
	private _downKey: string;
	private _targetY: number;
	private _lastCollisionTime: number;
	private prevRenderX: number = 0;
	private prevRenderY: number = 0;
	private movementFrozen: number = 0;
	private readonly startY: number;
	private readonly currentPosVec: { x: number; y: number };
	private readonly currentVelVec: { dx: number; dy: number };
	private readonly collisionPointVec: { x: number; y: number };
	private readonly finalPredictedImpactPointVec: { x: number; y: number };
	private static readonly MAX_PREDICTED_BOUNCES_DISPLAY = 10;
	private _reusableVelocityVector: VelocityValue;

	/**
	 * Handles keyboard keydown events for player control
	 */
	private readonly handleKeydown = (evt: KeyboardEvent): void => {
		switch (evt.code) {
			case this._upKey:
				this.upPressed = true;
				break;
			case this._downKey:
				this.downPressed = true;
				break;
		}
		this.updateDirection();
	};

	/**
	 * Handles keyboard keyup events for player control
	 */
	private readonly handleKeyup = (evt: KeyboardEvent): void => {
		switch (evt.code) {
			case this._upKey:
				this.upPressed = false;
				break;
			case this._downKey:
				this.downPressed = false;
				break;
		}
		this.updateDirection();
	};


	// =========================================
	// Constructor
	// =========================================
	/**
	 * Creates a new Player instance
	 * @param x The horizontal position
	 * @param y The vertical position
	 * @param ball The ball object for tracking and collision
	 * @param context The canvas rendering context
	 * @param position The player's position (left or right)
	 * @param type Whether the player is AI or human controlled
	 */
	constructor(
		public x: number,
		public y: number,
		protected readonly ball: Ball,
		protected readonly context: GameContext,
		position: PlayerPosition = PlayerPosition.LEFT,
		type: PlayerType = PlayerType.HUMAN
	) {
		if (!ball) {
			throw new Error('Ball must be provided to Player');
		}
		if (!context) {
			throw new Error('Context must be provided to Player');
		}
		this.startY = context.canvas.height * 0.5 - this.paddleHeight * 0.5;
		this.y = this.startY;
		this._position = position;
		this._type = type;
		this._targetY = this.startY;
		this._lastCollisionTime = 1000;
		this.upPressed = false;
		this.downPressed = false;
		this.direction = Direction.NONE;
		this.currentPosVec = { x: 0, y: 0 };
		this.currentVelVec = { dx: 0, dy: 0 };
		this.collisionPointVec = { x: 0, y: 0 };
		this.finalPredictedImpactPointVec = { x: 0, y: 0 };
		this._reusableVelocityVector = { dx: 0, dy: 0 };
		if (position === PlayerPosition.LEFT) {
			this._upKey = KEYS.PLAYER_LEFT_UP;
			this._downKey = KEYS.PLAYER_LEFT_DOWN;
			this._name = 'Player 1';
		} else {
			this._upKey = KEYS.PLAYER_RIGHT_UP;
			this._downKey = KEYS.PLAYER_RIGHT_DOWN;
			this._name = this._type === PlayerType.HUMAN ? 'Player 2' : 'Computer';
		}
		this.paddle = new Paddle(x, y, this.paddleWidth, this.paddleHeight, context);
		this.updateSizes();
	}

	/**
	 * Updates the player's paddle dimensions based on canvas size
	 */
	public updateSizes(): void {
		if (!this.context) return;
		
		const { width, height } = this.context.canvas;
		const sizes = calculateGameSizes(width, height);
		
		this.paddleWidth = sizes.PADDLE_WIDTH;
		this.paddleHeight = sizes.PADDLE_HEIGHT;
		this.speed = sizes.PADDLE_SPEED;
		this.paddle.updateDimensions(this.paddleWidth, this.paddleHeight);
		this.updateHorizontalPosition();
	}


	/**
	 * Updates player state for the current frame
	 */
	public update(ctx: GameContext, deltaTime: number, state: GameState): void {

		this.prevRenderX = this.x;
		this.prevRenderY = this.y;
		if (this.paddle) {
			this.paddle.setPreviousPosition(this.paddle.x, this.paddle.y);
		}
		const { width, height } = ctx.canvas;
		const sizes = calculateGameSizes(width, height);
		this.paddleHeight = sizes.PADDLE_HEIGHT;
		if (this._type === PlayerType.BACKGROUND && (state === GameState.PLAYING || state === GameState.COUNTDOWN)) {
			this.updateBackgroundInputs(ctx);
		}
		if (this._type === PlayerType.AI && (state === GameState.PLAYING || state === GameState.COUNTDOWN)) {
			this.updateAIInputs(ctx);
		}
		if (state === GameState.PLAYING) {
			this.updateMovement(deltaTime);
		}
		this.updateHorizontalPosition();
	}

	/**
	 * Draws the player's paddle using interpolation
	 * @param alpha Interpolation factor (0 to 1)
	 */
	public draw(ctx: GameContext, alpha: number): void {
		const interpolatedX = this.prevRenderX * (1 - alpha) + this.x * alpha;
		const interpolatedY = this.prevRenderY * (1 - alpha) + this.y * alpha;
		ctx.fillStyle = this.color;
		ctx.fillRect(interpolatedX, interpolatedY, this.paddleWidth, this.paddleHeight);
	}

	/**
	 * Sets up keyboard event listeners for player control
	 */
	public bindControls(): void {
		window.addEventListener('keydown', this.handleKeydown, { passive: true });
		window.addEventListener('keyup', this.handleKeyup, { passive: true });
	}

	/**
	 * Removes keyboard event listeners for player control
	 */
	public unbindControls(): void {
		this.upPressed = false;
		this.downPressed = false;
		this.direction = Direction.NONE;
		window.removeEventListener('keydown', this.handleKeydown);
		window.removeEventListener('keyup', this.handleKeyup);
	}

	/**
	 * Updates the horizontal position of the player's paddle.
	 * This method should be called whenever the player's x position changes.
	 */
	public updateHorizontalPosition(): void {
		const { width } = this.context.canvas;
		const sizes = calculateGameSizes(width, this.context.canvas.height);
	
		if (this._position === PlayerPosition.LEFT) {
			this.x = sizes.PLAYER_PADDING;
		} else {
			this.x = width - (sizes.PLAYER_PADDING + sizes.PADDLE_WIDTH);
		}
		this.paddle.setPosition(this.x, this.y);
	}

	/**
	 * Updates the paddle's position based on input direction
	 */
	protected updateMovement(deltaTime: number): void {
		if (this.movementFrozen > 0) {
			this.direction = Direction.NONE;
			this.movementFrozen -= deltaTime;
			if (this.movementFrozen < 0) this.movementFrozen = 0;
			return;
		}
		if (this.direction === Direction.NONE) return;
		const frameSpeed = this.speed * deltaTime;
		const newY = this.direction === Direction.UP 
			? this.y - frameSpeed 
			: this.y + frameSpeed;
		const maxY = this.context.canvas.height - this.paddleHeight;
		this.y = Math.min(Math.max(0, newY), maxY);
	}

	/**
	 * Updates the movement direction based on current key states
	 */
	protected updateDirection(): void {
		if (this.upPressed && this.downPressed) {
			this.direction = Direction.NONE;
		} else if (this.upPressed) {
			this.direction = Direction.UP;
		} else if (this.downPressed) {
			this.direction = Direction.DOWN;
		} else {
			this.direction = Direction.NONE;
		}
	}


	/**
	 * Public method to trigger an initial prediction calculation, usually at the start of a point.
	 * Checks if the ball is moving before calling the internal prediction logic.
	 */
	public calculateInitialPrediction(): void {
		if (!this.ball) return;
		const ballVelocity = this.ball.Velocity;
		if (ballVelocity.dx !== 0 || ballVelocity.dy !== 0) {
			this.predictBallTrajectory(this.ball.Position, ballVelocity);
			this._lastCollisionTime = 0;
		}
	}

	/**
	 * Predicts the ball's trajectory through multiple bounces until it heads back
	 * towards the player's paddle line. Updates `predictedBouncePoints` and `_targetY`.
	 * Now accounts for ball acceleration after simulated bounces.
	 */
	public predictBallTrajectory(
		startPoint: { x: number; y: number },
		initialVelocity: { dx: number; dy: number }
	): void {
		if (Date.now() - this._lastCollisionTime < 1000) {
			return;
		}
		this._lastCollisionTime = Date.now();

		const { width, height } = this.context.canvas;
		const ballRadius = this.ball.Size;
		const sizes = calculateGameSizes(width, height);
		const maxBouncesToSimulate = Player.MAX_PREDICTED_BOUNCES_DISPLAY; // This now acts as a simulation depth limit

		this.currentPosVec.x = startPoint.x;
		this.currentPosVec.y = startPoint.y;
		this.currentVelVec.dx = initialVelocity.dx;
		this.currentVelVec.dy = initialVelocity.dy;

		let simulatedCurrentSpeed = Math.sqrt(this.currentVelVec.dx * this.currentVelVec.dx + this.currentVelVec.dy * this.currentVelVec.dy);
		let simulatedSpeedMultiplier = this.ball.baseSpeed > 0 ? simulatedCurrentSpeed / this.ball.baseSpeed : BALL_CONFIG.ACCELERATION.INITIAL;
		simulatedSpeedMultiplier = Math.max(BALL_CONFIG.ACCELERATION.INITIAL, simulatedSpeedMultiplier);
		const playerPaddleEdgeX = this._position === PlayerPosition.LEFT
			? sizes.PLAYER_PADDING + this.paddleWidth
			: width - (sizes.PLAYER_PADDING + this.paddleWidth);
		const opponentPaddleEdgeX = this._position === PlayerPosition.LEFT
			? width - (sizes.PLAYER_PADDING + this.paddleWidth)
			: sizes.PLAYER_PADDING + this.paddleWidth;

		for (let bounceCount = 0; bounceCount < maxBouncesToSimulate; bounceCount++) {
			const collisionTimes = this._calculateCollisionTimes(
				this.currentPosVec,
				this.currentVelVec,
				ballRadius,
				height,
				playerPaddleEdgeX,
				opponentPaddleEdgeX
			);

			const { timeToCollision, collisionType } = this._determineEarliestCollision(collisionTimes);

			if (collisionType === 'none' || timeToCollision === Infinity) {
				this._targetY = this.y + this.paddleHeight / 2; // Default if no collision
				break;
			}

			this.collisionPointVec.x = this.currentPosVec.x + this.currentVelVec.dx * timeToCollision;
			this.collisionPointVec.y = this.currentPosVec.y + this.currentVelVec.dy * timeToCollision;

			if (collisionType === 'player') {
				this._handlePlayerCollision(this.collisionPointVec, height);
				break;
			}

			const reflection = this._handleReflection(
				collisionType as 'top' | 'bottom' | 'opponent',
				this.currentVelVec,
				simulatedSpeedMultiplier,
				this.ball.baseSpeed
			);
			this.currentVelVec.dx = reflection.newVel.dx;
			this.currentVelVec.dy = reflection.newVel.dy;
			simulatedSpeedMultiplier = reflection.newSpeedMultiplier;
			this.currentPosVec.x = this.collisionPointVec.x;
			this.currentPosVec.y = this.collisionPointVec.y;

			if (bounceCount === maxBouncesToSimulate - 1) {
				this._predictTargetYAtMaxBounces(
					this.currentPosVec,
					this.currentVelVec,
					playerPaddleEdgeX,
					ballRadius,
					height,
					this.paddleHeight
				);
			}
		}
	}

	private _calculateCollisionTimes(
		currentPos: { x: number; y: number },
		currentVel: { dx: number; dy: number },
		ballRadius: number,
		canvasHeight: number,
		playerPaddleEdgeX: number,
		opponentPaddleEdgeX: number
	): { timeToTop: number; timeToBottom: number; timeToOpponent: number; timeToPlayer: number } {
		let timeToTop = Infinity;
		if (currentVel.dy < 0) { timeToTop = (ballRadius - currentPos.y) / currentVel.dy; }

		let timeToBottom = Infinity;
		if (currentVel.dy > 0) { timeToBottom = (canvasHeight - ballRadius - currentPos.y) / currentVel.dy; }

		let timeToOpponent = Infinity;
		if (currentVel.dx !== 0) {
			if ((this._position === PlayerPosition.LEFT && currentVel.dx > 0)) {
				const targetX = opponentPaddleEdgeX - ballRadius;
				if (currentVel.dx !== 0) timeToOpponent = (targetX - currentPos.x) / currentVel.dx;
			} else if ((this._position === PlayerPosition.RIGHT && currentVel.dx < 0)) {
				const targetX = opponentPaddleEdgeX + ballRadius;
				if (currentVel.dx !== 0) timeToOpponent = (targetX - currentPos.x) / currentVel.dx;
			}
		}

		let timeToPlayer = Infinity;
		if (currentVel.dx !== 0) {
			if ((this._position === PlayerPosition.LEFT && currentVel.dx < 0)) {
				const targetX = playerPaddleEdgeX + ballRadius;
				if (currentVel.dx !== 0) timeToPlayer = (targetX - currentPos.x) / currentVel.dx;
			} else if ((this._position === PlayerPosition.RIGHT && currentVel.dx > 0)) {
				const targetX = playerPaddleEdgeX - ballRadius;
				if (currentVel.dx !== 0) timeToPlayer = (targetX - currentPos.x) / currentVel.dx;
			}
		}
		return { timeToTop, timeToBottom, timeToOpponent, timeToPlayer };
	}

	private _determineEarliestCollision(times: {
		timeToTop: number;
		timeToBottom: number;
		timeToOpponent: number;
		timeToPlayer: number;
	}): { timeToCollision: number; collisionType: 'top' | 'bottom' | 'opponent' | 'player' | 'none' } {
		const positiveTimes = [times.timeToTop, times.timeToBottom, times.timeToOpponent, times.timeToPlayer].filter(t => t > 1e-6);
		if (positiveTimes.length === 0) {
			return { timeToCollision: Infinity, collisionType: 'none' };
		}
		const timeToCollision = Math.min(...positiveTimes);
		const tolerance = 1e-6;
		if (Math.abs(timeToCollision - times.timeToTop) < tolerance) return { timeToCollision, collisionType: 'top' };
		if (Math.abs(timeToCollision - times.timeToBottom) < tolerance) return { timeToCollision, collisionType: 'bottom' };
		if (Math.abs(timeToCollision - times.timeToOpponent) < tolerance) return { timeToCollision, collisionType: 'opponent' };
		if (Math.abs(timeToCollision - times.timeToPlayer) < tolerance) return { timeToCollision, collisionType: 'player' };
		return { timeToCollision: Infinity, collisionType: 'none' };
	}

	private _handlePlayerCollision(collisionPoint: { x: number; y: number }, canvasHeight: number): void {
		this.finalPredictedImpactPointVec.x = collisionPoint.x;
		this.finalPredictedImpactPointVec.y = collisionPoint.y;
		const finalPredictedY = collisionPoint.y;
		const paddleCenterMinY = this.paddleHeight / 2;
		const paddleCenterMaxY = canvasHeight - this.paddleHeight / 2;
		this._targetY = Math.max(paddleCenterMinY, Math.min(paddleCenterMaxY, finalPredictedY));
	}

	private _handleReflection(
		collisionType: 'top' | 'bottom' | 'opponent',
		currentVel: { dx: number; dy: number },
		simulatedSpeedMultiplier: number,
		baseSpeed: number
	): { newVel: VelocityValue; newSpeedMultiplier: number } {
		this._reusableVelocityVector.dx = currentVel.dx;
		this._reusableVelocityVector.dy = currentVel.dy;

		if (collisionType === 'top' || collisionType === 'bottom') {
			this._reusableVelocityVector.dy *= -1;
		} else if (collisionType === 'opponent') {
			this._reusableVelocityVector.dx *= -1;
		}
		const newSimulatedSpeedMultiplier = Math.min(
			simulatedSpeedMultiplier + BALL_CONFIG.ACCELERATION.RATE,
			BALL_CONFIG.ACCELERATION.MAX_MULTIPLIER
		);
		const simulatedCurrentSpeed = baseSpeed * newSimulatedSpeedMultiplier;
		const magnitude = Math.sqrt(this._reusableVelocityVector.dx * this._reusableVelocityVector.dx + this._reusableVelocityVector.dy * this._reusableVelocityVector.dy);
		if (magnitude > 1e-6) {
			const normDx = this._reusableVelocityVector.dx / magnitude;
			const normDy = this._reusableVelocityVector.dy / magnitude;
			this._reusableVelocityVector.dx = normDx * simulatedCurrentSpeed;
			this._reusableVelocityVector.dy = normDy * simulatedCurrentSpeed;
		} else {
			this._reusableVelocityVector.dx = 0;
			this._reusableVelocityVector.dy = 0;
		}
		return { newVel: this._reusableVelocityVector, newSpeedMultiplier: newSimulatedSpeedMultiplier };
	}

	private _predictTargetYAtMaxBounces(
		currentPos: { x: number; y: number },
		currentVel: { dx: number; dy: number },
		playerPaddleEdgeX: number,
		ballRadius: number,
		canvasHeight: number,
		paddleHeight: number
	): void {
		let finalTimeToPlayerFallback = Infinity;
		if (currentVel.dx !== 0) {
			if ((this._position === PlayerPosition.LEFT && currentVel.dx < 0)) {
				const targetX = playerPaddleEdgeX + ballRadius;
				if (currentVel.dx !== 0) finalTimeToPlayerFallback = (targetX - currentPos.x) / currentVel.dx;
			} else if ((this._position === PlayerPosition.RIGHT && currentVel.dx > 0)) {
				const targetX = playerPaddleEdgeX - ballRadius;
				if (currentVel.dx !== 0) finalTimeToPlayerFallback = (targetX - currentPos.x) / currentVel.dx;
			}
		}
		if (finalTimeToPlayerFallback > 0 && finalTimeToPlayerFallback !== Infinity) {
			const finalPredictedYFallback = currentPos.y + currentVel.dy * finalTimeToPlayerFallback;
			const finalPredictedXFallback = currentPos.x + currentVel.dx * finalTimeToPlayerFallback;
			this.finalPredictedImpactPointVec.x = finalPredictedXFallback;
			this.finalPredictedImpactPointVec.y = finalPredictedYFallback;
			const paddleCenterMinY = paddleHeight / 2;
			const paddleCenterMaxY = canvasHeight - paddleHeight / 2;
			this._targetY = Math.max(paddleCenterMinY, Math.min(paddleCenterMaxY, finalPredictedYFallback));
		} else {
			this._targetY = this.y + paddleHeight / 2;
		}
	}

	/**
	 * Updates AI inputs based on ball position and game state
	 */
	protected updateAIInputs(ctx: GameContext): void {
		const vx = Math.abs(this.ball.Velocity.dx);
		const paddleCenter = this.y + (this.paddleHeight * 0.5);
		if (vx > 0) {
			const Width = ctx.canvas.width;
			const thresholdMs = (Width / vx) * 1.2 * 1000;
			if (Date.now() - this._lastCollisionTime < thresholdMs) {
				this.moveTowardsCenter(paddleCenter, ctx.canvas.height * 0.5);
				return;
			}
		}
		this.moveTowardsPredictedBallY(paddleCenter);
		this.updateDirection();
	}

	protected updateBackgroundInputs(ctx: GameContext): void {
		const paddleCenter = this.y + (this.paddleHeight * 0.5);
		const centerY = ctx.canvas.height * 0.5 - this.paddleHeight * 0.5;
		if (this.ball.dx === 0 && this.ball.dy === 0) {
			this.moveTowardsCenter(paddleCenter, centerY);
			return;
		}
		if (this._position === PlayerPosition.LEFT) {
			if (this.ball.dx >= 0) {
				this.moveTowardsCenter(paddleCenter, centerY);
			} else {
				this.trackBallWithDelay(paddleCenter);
			}
		} else {
			if (this.ball.dx <= 0) {
				this.moveTowardsCenter(paddleCenter, centerY);
			} else {
				this.trackBallWithDelay(paddleCenter);
			}
		}
	}
	
	/**
	 * AI helper method to move paddle towards center position
	 */
	private moveTowardsCenter(paddleCenter: number, centerY: number): void {
		const deadzone = this.paddleHeight * 0.1;
		const targetY = centerY + (this.paddleHeight * 0.5);
		if (Math.abs(paddleCenter - targetY) < deadzone) {
			this.upPressed = false;
			this.downPressed = false;
		} else {
			this.upPressed = paddleCenter > targetY;
			this.downPressed = paddleCenter < targetY;
		}
		this.updateDirection();
	}

	/**
	 * AI helper method to move paddle towards the predicted ball Y position
	 */
	private moveTowardsPredictedBallY(paddleCenter: number): void {
		const deadzone = this.paddleHeight * 0.1;

		if (Math.abs(paddleCenter - this._targetY) < deadzone) {
			this.upPressed = false;
			this.downPressed = false;
		} else {
			this.upPressed = paddleCenter > this._targetY;
			this.downPressed = paddleCenter < this._targetY;
		}
	}

	/**
	 * AI helper method to track the ball with realistic movement
	 */
	private trackBallWithDelay(paddleCenter: number): void {
		const targetY = this.ball.y;
		const deadzone = this.paddleHeight * 0.1;
		
		if (Math.abs(paddleCenter - targetY) < deadzone) {
			this.upPressed = false;
			this.downPressed = false;
		} else {
			this.upPressed = paddleCenter > targetY;
			this.downPressed = paddleCenter < targetY;
		}
		this.updateDirection();
	}

	////////////////////////////////////////////////////////////
	// Helper methods
	////////////////////////////////////////////////////////////
	public freezeMovement(duration: number): void { this.movementFrozen = duration; }
	public stopMovement(): void { this.direction = Direction.NONE; }
	public givePoint(): void { this.score += 1; }
	public resetScore(): void { this.score = 0; }
	public resetPosition(): void {
		const height = this.context.canvas.height;
		this.y = height * 0.5 - this.paddleHeight * 0.5;
		this.paddle.setPosition(this.x, this.y);
	}

	/**
	 * Synchronizes the previous render state (prevRenderX, prevRenderY)
	 * to the current x and y positions. This is crucial for correct drawing
	 * when the game is paused and Player.update() might not be called,
	 * but the player's position has been updated by external logic like ResizeManager.
	 */
	public syncPrevRenderStates(): void {
		this.prevRenderX = this.x;
		this.prevRenderY = this.y;
		// If the Paddle object itself had its own prevRenderX/Y for interpolation,
		// you might sync it here too, e.g., this.paddle.syncPrevRenderStates()
		// For now, assuming Player's own prevRenderX/Y are primary for its drawing.
	}

	////////////////////////////////////////////////////////////
	// Getters and setters
	////////////////////////////////////////////////////////////
	public get name(): string { return this._name; }
	public get PlayerType(): PlayerType { return this._type; }
	public get Score(): number { return this.score; }
	public get Position(): PlayerPosition { return this._position; }
	
	public setName(name: string): void { this._name = name; }
	public setPlayerType(type: PlayerType): void { this._type = type; }
	public setColor(newColor: string): void { this.color = newColor; }	
}
